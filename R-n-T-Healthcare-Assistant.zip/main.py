def main():
  print("Hey There! Welcome to R 'n T Health Assistant!")
  print("How are you feeling today?")
  print("a.) Healthy")
  print("b.) Sick")
  print("c.) Very Sick")
  print("(Enter 'quit' to quit)")

  a = input("").lower()

  if a == "quit":
      print("Bye! bye!")
      return
  elif a in ["healthy", "sick", "very sick"]:
      if a == "healthy":
          choice = input("That's great! Would you like to know some recipes? (Yes/No) ").lower()
          if choice == "yes":
              print("1.) Pizza Casserole")
              print("2.) French Bread Pizza")
              print("3.) Tofu Fried Rice")
              print("4.) Thai Curry Vegetable and Tofu Soup")
          else:
              print("Okay, have a good day!")
      elif a == "sick":
          choice = input("I hope you feel better soon. These are some recipes to surely make you feel better! Would you like to know them? (Yes/No) ").lower()
          if choice == "yes":
              print("1.) Chicken & Broccoli Casserole")
              print("2.) Chicken Cutlets with Sun-Dried Tomato Cream Sauce")
              print("3.) Eggs in Tomato Sauce with Chickpeas & Spinach")
              print("4.) Pea Soup")
          else:
              print("Okay, have a good day!")
      elif a == "very sick":
          choice = input("Oh no. I am very sorry to hear that. It is recommended to seek a doctor's help. If you want, can I suggest some recipes? (Yes/No) ").lower()
          if choice == "yes":
              print("1.) Vegetable Soup")
              print("2.) Chicken Noodle Soup")
              print("3.) Spinach Rice")
              print("4.) Tomato Soup")
          else:
              print("Okay, take care!")

  else:
      print("Invalid input. Please select one of the provided options.")

if __name__ == "__main__":
  main()

def calculate_bmi(weight, height):
  if weight <= 0 or height <= 0:
      return None    #Return None if weight or height is non-positive
  bmi = weight / (height * height)
  return bmi

def interpret_bmi(bmi):
  if bmi is None:
      return "Invalid input"   #Handle invalid input
  elif bmi < 18.5:
      return "Underweight"
  elif 18.5 <= bmi < 24.9:
      return "Normal weight"
  elif 24.9 <= bmi < 29.9:
      return "Overweight"
  else:
      return "Obese"

def main():
  print("Welcome to the BMI Calculator!")
  weight = float(input("Enter your weight in kilograms: "))
  height = float(input("Enter your height in meters: "))

  bmi = calculate_bmi(weight, height)
  if bmi is not None:
      print(f"Your BMI is: {bmi:.2f}")
      interpretation = interpret_bmi(bmi)
      print(f"You are classified as: {interpretation}")
  else:
      print("Invalid input. Please enter positive values for weight and height.")

if __name__ == "__main__":
  main()
